﻿
namespace PagueVeloz.Application.Accounts
{
    public class AccountCreateOutputDto
    {
        public string AccountId { get; set; }
        public string ClientId { get; set; }
    }
}
