﻿
namespace PagueVeloz.Application.Clients
{
    public class ClientsCreateOutputDto
    {
        public string ClientId { get; set; }
    }
}
