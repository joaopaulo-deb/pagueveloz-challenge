﻿
using PagueVeloz.Domain.Entities;

namespace PagueVeloz.Domain.Contracts
{
    public interface IEventRepository : IBaseRepository<Event>
    {
    }
}
