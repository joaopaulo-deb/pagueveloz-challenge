﻿
namespace PagueVeloz.Domain.Enums
{
    public enum Currency
    {
        BRL = 1
    }
}
