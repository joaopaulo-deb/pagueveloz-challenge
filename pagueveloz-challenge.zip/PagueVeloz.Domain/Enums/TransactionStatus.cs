﻿
namespace PagueVeloz.Domain.Enums
{
    public enum TransactionStatus
    {
        success = 1,
        failed = 2,
        pending = 3
    }
}
