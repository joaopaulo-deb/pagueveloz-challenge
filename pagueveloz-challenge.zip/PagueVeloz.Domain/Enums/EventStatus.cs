﻿
namespace PagueVeloz.Domain.Enums
{
    public enum EventStatus
    {
        Success = 1,
        Failed = 2
    }
}
